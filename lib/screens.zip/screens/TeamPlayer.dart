import 'package:flutter/material.dart';

class PlayerPosition {
  final String name;
  final String description;
  final String imagePath;
  final String abbreviation;
  final List<String> famousPlayers;
  final List<String> keySkills;

  PlayerPosition({
    required this.name,
    required this.description,
    required this.imagePath,
    required this.abbreviation,
    required this.famousPlayers,
    required this.keySkills,
  });
}

class PlayerPositionsPage extends StatelessWidget {
  PlayerPositionsPage({Key? key}) : super(key: key);

  final List<PlayerPosition> positions = [
    PlayerPosition(
      name: 'พอยต์การ์ด (Point Guard)',
      abbreviation: 'PG',
      description: 'ผู้เล่นที่ทำหน้าที่ควบคุมเกมและนำบอลขึ้นสนาม มักเป็นผู้เล่นที่มีทักษะการส่งบอลที่ดีและสามารถสร้างโอกาสให้เพื่อนร่วมทีม',
      imagePath: 'assets/images/point_guard.jpg',
      famousPlayers: ['สตีเฟน เคอร์รี่', 'คริส พอล', 'ดามิอาน ลิลลาร์ด'],
      keySkills: ['การส่งบอล', 'การควบคุมเกม', 'การยิงระยะไกล', 'ความคล่องตัวสูง'],
    ),
    PlayerPosition(
      name: 'ชูตติ้งการ์ด (Shooting Guard)',
      abbreviation: 'SG',
      description: 'ผู้เล่นที่เน้นการทำแต้มโดยเฉพาะการยิงจากระยะไกล มักมีทักษะการยิงที่เฉียบคมและสามารถสร้างโอกาสการทำแต้มด้วยตัวเองได้',
      imagePath: 'assets/images/shooting_guard.jpg',
      famousPlayers: ['ไมเคิล จอร์แดน', 'โคบี ไบรอันท์', 'เจมส์ ฮาร์เดน'],
      keySkills: ['การยิงจากระยะไกล', 'การสร้างโอกาสทำแต้ม', 'การเคลื่อนที่ไร้บอล'],
    ),
    PlayerPosition(
      name: 'สมอลฟอร์เวิร์ด (Small Forward)',
      abbreviation: 'SF',
      description: 'ผู้เล่นที่มีความสามารถรอบด้านทั้งในเกมรุกและเกมรับ มักมีร่างกายที่แข็งแรงและมีความคล่องตัวสูง',
      imagePath: 'assets/images/small_forward.jpg',
      famousPlayers: ['เลบรอน เจมส์', 'เควิน ดูแรนท์', 'คาวาย เลโอนาร์ด'],
      keySkills: ['ความสามารถรอบด้าน', 'การทำแต้ม', 'การป้องกัน', 'การดึงกระดานบอล'],
    ),
    PlayerPosition(
      name: 'พาวเวอร์ฟอร์เวิร์ด (Power Forward)',
      abbreviation: 'PF',
      description: 'ผู้เล่นที่มีร่างกายแข็งแรงและมักเล่นใกล้ห่วง มีหน้าที่ในการดึงกระดานบอลและป้องกันในเขตสามวินาที',
      imagePath: 'assets/images/power_forward.jpg',
      famousPlayers: ['ทิม ดันแคน', 'เดิร์ค โนวิตซกี้', 'ยานนิส อันเตโตคุนโป'],
      keySkills: ['พละกำลัง', 'การดึงกระดานบอล', 'การป้องกันใต้แป้น', 'การทำแต้มในเขต'],
    ),
    PlayerPosition(
      name: 'เซ็นเตอร์ (Center)',
      abbreviation: 'C',
      description: 'ผู้เล่นที่มีร่างกายใหญ่และสูงที่สุดในทีม มีหน้าที่ป้องกันใต้แป้นและทำแต้มในเขตสามวินาที',
      imagePath: 'assets/images/center.jpg',
      famousPlayers: ['ชาคิล โอนีล', 'ฮาคีม โอลาจูวอน', 'โจเอล เอมบิด'],
      keySkills: ['ความสูง', 'การบล็อกช็อต', 'การป้องกันใต้แป้น', 'การดึงกระดานบอล'],
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ตำแหน่งผู้เล่นบาสเกตบอล'),
        backgroundColor: Colors.orange,
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16.0),
        itemCount: positions.length,
        itemBuilder: (context, index) {
          final position = positions[index];
          return GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => PositionDetailPage(position: position),
                ),
              );
            },
            child: Card(
              margin: const EdgeInsets.only(bottom: 16.0),
              elevation: 4.0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.0),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ClipRRect(
                    borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(12.0),
                    ),
                    child: Image.asset(
                      position.imagePath,
                      height: 200,
                      width: double.infinity,
                      fit: BoxFit.cover,
                      // สามารถใช้ NetworkImage แทนได้
                      // Image.network(position.imageUrl, height: 200, width: double.infinity, fit: BoxFit.cover),
                      errorBuilder: (context, error, stackTrace) {
                        return Container(
                          height: 200,
                          width: double.infinity,
                          color: Colors.grey[300],
                          child: const Icon(
                            Icons.image_not_supported,
                            size: 50,
                            color: Colors.grey,
                          ),
                        );
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal:
                                    8.0,
                                vertical: 4.0,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.orange,
                                borderRadius: BorderRadius.circular(4.0),
                              ),
                              child: Text(
                                position.abbreviation,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            const SizedBox(width: 8.0),
                            Expanded(
                              child: Text(
                                position.name,
                                style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8.0),
                        Text(
                          position.description,
                          style: TextStyle(fontSize: 14, color: Colors.grey[800]),
                        ),
                        const SizedBox(height: 12.0),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            TextButton(
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => PositionDetailPage(position: position),
                                  ),
                                );
                              },
                              child: const Text('ดูรายละเอียดเพิ่มเติม'),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class PositionDetailPage extends StatelessWidget {
  final PlayerPosition position;

  const PositionDetailPage({Key? key, required this.position}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(position.name),
        backgroundColor: Colors.orange,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Hero(
              tag: position.name,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12.0),
                child: Image.asset(
                  position.imagePath,
                  height: 250,
                  width: double.infinity,
                  fit: BoxFit.cover,
                  // สามารถใช้ NetworkImage แทนได้
                  // Image.network(position.imageUrl, height: 250, width: double.infinity, fit: BoxFit.cover),
                  errorBuilder: (context, error, stackTrace) {
                    return Container(
                      height: 250,
                      width: double.infinity,
                      color: Colors.grey[300],
                      child: const Icon(
                        Icons.image_not_supported,
                        size: 50,
                        color: Colors.grey,
                      ),
                    );
                  },
                ),
              ),
            ),
            const SizedBox(height: 16.0),
            Card(
              elevation: 2.0,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8.0,
                            vertical: 4.0,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.orange,
                            borderRadius: BorderRadius.circular(4.0),
                          ),
                          child: Text(
                            position.abbreviation,
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8.0),
                        Text(
                          position.name,
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16.0),
                    const Text(
                      'คำอธิบาย',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8.0),
                    Text(
                      position.description,
                      style: const TextStyle(fontSize: 16),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16.0),
            Card(
              elevation: 2.0,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'ทักษะที่สำคัญ',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8.0),
                    Wrap(
                      spacing: 8.0,
                      runSpacing: 8.0,
                      children: position.keySkills.map((skill) {
                        return Chip(
                          label: Text(skill),
                          backgroundColor: Colors.orange[100],
                        );
                      }).toList(),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16.0),
            Card(
              elevation: 2.0,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'ผู้เล่นที่มีชื่อเสียง',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8.0),
                    ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: position.famousPlayers.length,
                      itemBuilder: (context, index) {
                        return ListTile(
                          leading: const Icon(Icons.sports_basketball),
                          title: Text(position.famousPlayers[index]),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}s