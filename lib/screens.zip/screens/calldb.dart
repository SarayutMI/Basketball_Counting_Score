import 'dart:io';
import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

Future<String> getDatabasePath(String dbName) async {
  final databasePath = await getDatabasesPath();
  final path = join(databasePath, dbName);
  return path;
}

Future<void> findDatabasePath() async {
  final dbPath = await getDatabasePath('game_records.db');
  print('Database Path (Using sqflite): $dbPath');

  // ค้นหาโดยใช้คำสั่ง find ใน Terminal (Mac)
  try {
    final result = await Process.run('find', ['/', '-name', 'game_records.db']);
    if (result.exitCode == 0 && result.stdout.isNotEmpty) {
      print('Database Path (Using find command): ${result.stdout}');
    } else {
      print('Database file not found using find command.');
    }
  } catch (e) {
    print('Error executing find command: $e');
  }
}

void main() async {
  await findDatabasePath();
}