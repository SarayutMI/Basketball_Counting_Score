import 'package:flutter/material.dart';
import 'basketball_screen.dart';
import 'game_records_screen.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;
  int _score = 20; // Variable for storing score

  // List of screens for Bottom Navigation (leave it empty for now)
  final List<Widget> _screens = [];

// Function to handle navigation
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    // Navigate to respective screens based on index
    if (index == 0) {
      // Navigate to Basketball Screen (assuming HomeScreen)
      print("Basketball screen");
    } else if (index == 1) {
      // Navigate to Settings Screen
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => GameRecordsScreen()), //change this
      );
    } else if (index == 2) {
      // Navigate to Statistics Screen (GameRecordsScreen)
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => GameRecordsScreen()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // Title will be aligned to the left
        title: Align(
          alignment: Alignment.centerLeft,
          child: Text(
            'SPORT SCORE',
            style: TextStyle(
              color: Colors.black,
              fontSize: 35,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Row(
              children: [
                Image.asset(
                  'assets/images/point_icon.png', // Path to the score icon image
                  width: 30, // Width of the image
                  height: 30, // Height of the image
                ),
                Text(
                  '  $_score', // Score on the right side
                  style: TextStyle(color: Colors.black, fontSize: 20),
                ),
              ],
            ),
          ),
        ],
      ),

      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start, // จัดให้เริ่มต้นที่ด้านบน
          crossAxisAlignment:
              CrossAxisAlignment.center, // จัดให้ตรงกลางในแนวนอน
          children: [

            SizedBox(height: 16), // เว้นระยะห่างเล็กน้อยจาก AppBar
            
            Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: 16.0,
              ), // เว้นขอบซ้ายขวา 16
              child: GestureDetector(
                onTap: () {
                   Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => BasketballScreen()),
                );
                },
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20), // ทำมุมโค้ง
                  child: Stack(
                    alignment:
                        Alignment.center, // จัดตำแหน่งของข้อความให้กลางภาพ
                    children: [
                      Image.asset(
                        'assets/images/Basketball.png', // Path ของภาพ
                        width: double.infinity, // ทำให้ความกว้างเต็มหน้าจอ
                        height: 100, // ปรับความสูงตามที่ต้องการ
                        fit: BoxFit.cover, // ทำให้ภาพเต็มขนาดโดยไม่ยืดเบี้ยว
                      ),
                      Positioned(
                        child: Text(
                          'Basketball', // ข้อความที่ต้องการแสดง
                          style: TextStyle(
                            color: Colors.white, // สีข้อความ
                            fontSize: 30, // ขนาดตัวอักษร
                            fontWeight: FontWeight.bold, // ตัวหนา
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),

            SizedBox(height: 7), // เว้นระยะระหว่างภาพและปุ่มอื่นๆ

            Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: 16.0,
              ), // เว้นขอบซ้ายขวา 16
              child: GestureDetector(
                onTap: () {
                  // ใส่โค้ดที่ต้องการเมื่อคลิกปุ่มนี้
                  print('Image tapped!');
                },
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20), // ทำมุมโค้ง
                  child: Stack(
                    alignment:
                        Alignment.center, // จัดตำแหน่งของข้อความให้กลางภาพ
                    children: [
                      Image.asset(
                        'assets/images/Tennis.png', // Path ของภาพ
                        width: double.infinity, // ทำให้ความกว้างเต็มหน้าจอ
                        height: 100, // ปรับความสูงตามที่ต้องการ
                        fit: BoxFit.cover, // ทำให้ภาพเต็มขนาดโดยไม่ยืดเบี้ยว
                      ),
                      Positioned(
                        child: Text(
                          'Tennis', // ข้อความที่ต้องการแสดง
                          style: TextStyle(
                            color: Colors.white, // สีข้อความ
                            fontSize: 30, // ขนาดตัวอักษร
                            fontWeight: FontWeight.bold, // ตัวหนา
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          
            SizedBox(height: 7), // เว้นระยะระหว่างภาพและปุ่มอื่นๆ

            Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: 16.0,
              ), // เว้นขอบซ้ายขวา 16
              child: GestureDetector(
                onTap: () {
                  // ใส่โค้ดที่ต้องการเมื่อคลิกปุ่มนี้
                  print('Image tapped!');
                },
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20), // ทำมุมโค้ง
                  child: Stack(
                    alignment:
                        Alignment.center, // จัดตำแหน่งของข้อความให้กลางภาพ
                    children: [
                      Image.asset(
                        'assets/images/Volleyball.png', // Path ของภาพ
                        width: double.infinity, // ทำให้ความกว้างเต็มหน้าจอ
                        height: 100, // ปรับความสูงตามที่ต้องการ
                        fit: BoxFit.cover, // ทำให้ภาพเต็มขนาดโดยไม่ยืดเบี้ยว
                      ),
                      Positioned(
                        child: Text(
                          ' Volleyball', // ข้อความที่ต้องการแสดง
                          style: TextStyle(
                            color: Colors.white, // สีข้อความ
                            fontSize: 30, // ขนาดตัวอักษร
                            fontWeight: FontWeight.bold, // ตัวหนา
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),

            SizedBox(height: 7), // เว้นระยะระหว่างภาพและปุ่มอื่นๆ

            Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: 16.0,
              ), // เว้นขอบซ้ายขวา 16
              child: GestureDetector(
                onTap: () {
                  // ใส่โค้ดที่ต้องการเมื่อคลิกปุ่มนี้
                  print('Image tapped!');
                },
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20), // ทำมุมโค้ง
                  child: Stack(
                    alignment:
                        Alignment.center, // จัดตำแหน่งของข้อความให้กลางภาพ
                    children: [
                      Image.asset(
                        'assets/images/Football.png', // Path ของภาพ
                        width: double.infinity, // ทำให้ความกว้างเต็มหน้าจอ
                        height: 100, // ปรับความสูงตามที่ต้องการ
                        fit: BoxFit.cover, // ทำให้ภาพเต็มขนาดโดยไม่ยืดเบี้ยว
                      ),
                      Positioned(
                        child: Text(
                          'Football', // ข้อความที่ต้องการแสดง
                          style: TextStyle(
                            color: Colors.white, // สีข้อความ
                            fontSize: 30, // ขนาดตัวอักษร
                            fontWeight: FontWeight.bold, // ตัวหนา
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),

            SizedBox(height: 7), // เว้นระยะระหว่างภาพและปุ่มอื่นๆ

            Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: 16.0,
              ), // เว้นขอบซ้ายขวา 16
              child: GestureDetector(
                onTap: () {
                  // ใส่โค้ดที่ต้องการเมื่อคลิกปุ่มนี้
                  print('Image tapped!');
                },
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20), // ทำมุมโค้ง
                  child: Stack(
                    alignment:
                        Alignment.center, // จัดตำแหน่งของข้อความให้กลางภาพ
                    children: [
                      Image.asset(
                        'assets/images/Badminton.png', // Path ของภาพ
                        width: double.infinity, // ทำให้ความกว้างเต็มหน้าจอ
                        height: 100, // ปรับความสูงตามที่ต้องการ
                        fit: BoxFit.cover, // ทำให้ภาพเต็มขนาดโดยไม่ยืดเบี้ยว
                      ),
                      Positioned(
                        child: Text(
                          'Badminton', // ข้อความที่ต้องการแสดง
                          style: TextStyle(
                            color: Colors.white, // สีข้อความ
                            fontSize: 30, // ขนาดตัวอักษร
                            fontWeight: FontWeight.bold, // ตัวหนา
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),

            SizedBox(height: 7), // เว้นระยะระหว่างภาพและปุ่มอื่นๆ

            Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: 16.0,
              ), // เว้นขอบซ้ายขวา 16
              child: GestureDetector(
                onTap: () {
                  // ใส่โค้ดที่ต้องการเมื่อคลิกปุ่มนี้
                  print('Image tapped!');
                },
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20), // ทำมุมโค้ง
                  child: Stack(
                    alignment:
                        Alignment.center, // จัดตำแหน่งของข้อความให้กลางภาพ
                    children: [
                      Image.asset(
                        'assets/images/TableTennis.png', // Path ของภาพ
                        width: double.infinity, // ทำให้ความกว้างเต็มหน้าจอ
                        height: 100, // ปรับความสูงตามที่ต้องการ
                        fit: BoxFit.cover, // ทำให้ภาพเต็มขนาดโดยไม่ยืดเบี้ยว
                      ),
                      Positioned(
                        child: Text(
                          'TableTennis', // ข้อความที่ต้องการแสดง
                          style: TextStyle(
                            color: Colors.white, // สีข้อความ
                            fontSize: 30, // ขนาดตัวอักษร
                            fontWeight: FontWeight.bold, // ตัวหนา
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),            
          
          ],
        ),
      ),



        bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.sports_basketball),
            label: 'Basketball',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: 'Settings',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.bar_chart),
            label: 'Statistics',
          ),
        ],
      ),
    );
  }
}
