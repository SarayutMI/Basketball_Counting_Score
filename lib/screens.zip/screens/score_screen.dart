// score_screen.dart
import 'package:flutter/material.dart';

class ScoreScreen extends StatefulWidget {
  final String sport;
  ScoreScreen({required this.sport});

  @override
  _ScoreScreenState createState() => _ScoreScreenState();
}

class _ScoreScreenState extends State<ScoreScreen> {
  int team1Score = 0;
  int team2Score = 0;

  void incrementScore(int team) {
    setState(() {
      if (team == 1) team1Score++;
      else team2Score++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('${widget.sport} Scoreboard')),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text('Team 1: $team1Score', style: TextStyle(fontSize: 24)),
          ElevatedButton(onPressed: () => incrementScore(1), child: Text('Increase Team 1 Score')),
          Text('Team 2: $team2Score', style: TextStyle(fontSize: 24)),
          ElevatedButton(onPressed: () => incrementScore(2), child: Text('Increase Team 2 Score')),
        ],
      ),
    );
  }
}